<?php
$conn = mysqli_connect("localhost","root","","b2b");

extract($_POST);


$sql = "INSERT INTO `b2btable`(`firstname`, `lastname`, `email`, `phone`, `jobtitle`, `companysize`, `industry`, `country`, `optin`) VALUES ('$firstname','$lastname','$email','$phone','$jobtitle','$companysize','$industry','$country','$optin')";

$query = mysqli_query($conn,$sql);
header("Location: thankyou.html");
exit();

?>